//
//  Stevia.h
//  Stevia
//
//  Created by Sacha Durand Saint Omer on 24/10/15.
//  Copyright © 2015 Sacha Durand Saint Omer. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Stevia.
FOUNDATION_EXPORT double SteviaVersionNumber;

//! Project version string for Stevia.
FOUNDATION_EXPORT const unsigned char SteviaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Stevia/PublicHeader.h>


