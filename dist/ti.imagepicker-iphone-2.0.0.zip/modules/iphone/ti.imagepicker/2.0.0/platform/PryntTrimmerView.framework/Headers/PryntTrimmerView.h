//
//  PryntTrimmerView.h
//  PryntTrimmerView
//
//  Created by Henry on 24/04/2018.
//  Copyright © 2018 CocoaPods. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PryntTrimmerView.
FOUNDATION_EXPORT double PryntTrimmerViewVersionNumber;

//! Project version string for PryntTrimmerView.
FOUNDATION_EXPORT const unsigned char PryntTrimmerViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PryntTrimmerView/PublicHeader.h>


